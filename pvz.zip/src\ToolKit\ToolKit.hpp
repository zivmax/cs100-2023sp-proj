#ifndef TOOLKIT_HPP__
#define TOOLKIT_HPP__

void stop(); // Causes a segmentation fault


void loop(); // Causes a infinite loop


#define STOP stop()
#define LOOP loop()

#endif // !TOOLKIT_HPP__