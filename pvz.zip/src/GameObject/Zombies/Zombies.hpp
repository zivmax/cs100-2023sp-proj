#include "GameObject.hpp"

enum class ZombieType {
    REGULAR,
    BUCKET,
    POLE,
};

class ZombieBase : public GameObject
{
    public:
        ZombieBase(pGameWorld belonging_world, ImageID imageID, AnimID animID, int AP, int HP, int x, int y);

        virtual void OnClick() override;
        void OnCollision(const GameObject &other) override;
        void UpdateEatingStatus();


    protected:
        bool m_is_eating = false;
};

class RegularZombie : public ZombieBase
{
    public:
        RegularZombie(int x, int y, pGameWorld belonging_world);

        virtual void Update() override;
};


class BucketZombie : public ZombieBase
{
    public:
        BucketZombie(int x, int y, pGameWorld belonging_world);

        virtual void Update() override;

    private:
        bool m_has_bucket = true;
};

class PoleZombie : public ZombieBase
{
    public:
        PoleZombie(int x, int y, pGameWorld belonging_world);

        virtual void Update() override;
        void ExtendHitBox();
        void StartJump();

    private:
        bool m_is_running = true;
        bool m_is_playing = false;
        bool m_is_extended = false;
        int m_speed = -1;
        int m_jump_anime_frames_left = -1;
        pGameObject_weak m_extended_box = pGameObject_weak();
};
