#include "Seeds.hpp"

PeaShooterSeed::PeaShooterSeed(int x, pGameWorld belonging_world)
    : SeedBase(belonging_world, IMGID_SEED_PEASHOOTER, ObjectOnHands::PEA_SHOOTER_SEED, 240, 100, x) {}

