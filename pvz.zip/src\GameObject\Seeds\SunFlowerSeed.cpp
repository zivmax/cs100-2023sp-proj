#include "Seeds.hpp"

SunFlowerSeed::SunFlowerSeed(int x, pGameWorld belonging_world)
    : SeedBase(belonging_world, IMGID_SEED_SUNFLOWER, ObjectOnHands::SUN_FLOWER_SEED, 240, 50, x) {}

